/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
//ABH3　CAN用　Arduino 　Host
//CAN通信部分
//2023.2.10　Waco Giken Co.,Ltd. Ishikawa

#include "ABH3CAN.h"
#include <mcp2515_can.h>
#include <SPI.h>

mcp2515_can CAN0(9);                               // MCP2515CSをArduino　D9ピンに接続

/***************************************************************/
//CAN アドレス設定
//引数：
//unsigned char abh3:ABH3のアドレス
//unsigned char host:HOSTのアドレス
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：なし
/***************************************************************/
void  can_setadrs(unsigned char abh3, unsigned char host, ABH3CAN * par) {
  par->SETTING.abh3_adrs = abh3;               //ABH3のCAN　アドレス設定
  par->SETTING.host_adrs = host;               //HOSTのCAN　アドレス設定
}


/***************************************************************/
//MCP2515初期設定
//引数：int bps 0:250kbps 1:500kbps 2:1000kbps
//戻り値：初期化成功:1　　失敗:0
/***************************************************************/
int can_init(int bps)
{
  int bps_set; 
  unsigned char clockset= MCP_16MHz;               //CANボードのシステムクロック定義
  
  switch (bps) {
    case 0:
      bps_set = CAN_250KBPS;
      break;
    case 1:
      bps_set = CAN_500KBPS;
      break;
    case 2:
      bps_set = CAN_1000KBPS;
      break;
    default:
      bps_set = CAN_250KBPS;
      break;
  }

  if (CAN0.begin(bps_set,clockset) == CAN_OK) { //MCP2515　供給クロック16MHz、ボーレート500KBPSに設定
    pinMode(CAN0_INT, INPUT);
    return 1;
  }
  else {
    return 0;
  }

}
/***************************************************************/
//CAN通信データ受信
//引数:
//unsigned long *canid　：    　受信したCANIDを格納するポインタ
//unsigned long *candata　：  　受信したデータを格納するポインタ
//unsigned long *num　：      　受信したデータ数を格納するポインタ
//戻り値：　受信成功:1　　失敗:0
/***************************************************************/
int can_rx(unsigned long *canid, unsigned char *candata, unsigned char *num)
{

  for (int i = 0; i < CAN_TIMEOUT ; i++) {
    if (!digitalRead(CAN0_INT)) {                     //受信バッファにデータ格納で　CAN0_INT　=>　Low
      CAN0.readMsgBufID(canid, num, candata);           // 受信したCANID、データ、データ数を取得する。

#ifdef DEBUG_PRINT
      com_dump(*canid, candata, *num, 0);               //受信結果を表示
#endif
      //*canid &= 0x7fffffff;                            // CANIDの拡張CANID受信のbit(bit31)をゼロにする.
      *canid   &= 0x00ffffff;                              //2023.08.28プライオリティビットもマスクする
      return 1;
    }
    delay(1);
  }
  return 0;
}

/***************************************************************/
//CAN通信データ送信
//引数:
//unsigned long canid　：　    送信するCANID
//unsigned long *candata　：　 送信データを格納したポインタ
//unsigned long num　：　      送信データ数
//戻り値：　送信成功:1　失敗:0
/***************************************************************/
int can_tx(unsigned long canid, unsigned char *candata, unsigned char num)
{
  if (CAN0.sendMsgBuf(canid, 1, num, candata) != CAN_OK) { //送信処理　引数の'1'は拡張CANIDを指定

#ifdef DEBUG_PRINT
    Serial.println("Error Sending Message...");
#endif
    return 0;
  }
#ifdef DEBUG_PRINT
  com_dump(canid, candata, num, 1);                     //送信結果を表示
#endif

  return 1;
}

/***************************************************************/
//シングルパケットDP0　初期化関数
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　初期化成功:1　　失敗:0
/***************************************************************/
int abh3_can_init(ABH3CAN *par) {
  par->DP0S.val = 0;                        //DP0S(指令関連）の全ての値をゼロに設定
  if (! abh3_can_DP0(par)) {
    return 0;
  }
  return 1;
}
