/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//ABH3　CAN用　Arduino 　Host
//ブロードキャスト操作部分
//2021.1.19　Waco Giken Co.,Ltd. Ishikawa

#include "ABH3CAN.h"
/***************************************************************/
// abh3_can_reqBRD本体
//引数：
//int num : ブロードキャスト番号
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int _abh3_can_reqBRD(int num, ABH3CAN *par)
{
  unsigned char tx_data[3] = {(unsigned char)num, 0xff, 0x00};   //ブロードキャストパケットのリクエスト送信データを生成
  unsigned char *rx_data;
  unsigned char n;
  unsigned long canid, tmp_canid,abh3_adrs, host_adrs;
  TMPDATA tmp_packet;

//-------------------------------------------------------------　送信CANIDの設定
  abh3_adrs = (unsigned long)par->SETTING.abh3_adrs;
  host_adrs = (unsigned long)par->SETTING.host_adrs;
  canid = CANID_BRS;
  canid = (canid << 16) | (abh3_adrs << 8)  |  (host_adrs);
//-------------------------------------------------------------

  if (! can_tx(canid, tx_data ,sizeof(tx_data))) {              //CAN送信処理
    return 0;
  }
  
//------------------------------------------------------------- 受信CANIDの設定  
  canid = CANID_BRR;
  canid = (canid << 16) | ((num) << 8)  |  (abh3_adrs);
//-------------------------------------------------------------
  
  if (! can_rx(&tmp_canid, tmp_packet.d, &n)) {                 //CAN受信処理
      return 0;
  }
  if (tmp_canid != canid || n != 8){                             //受信したCANIDとデータ数の整合チェック
     return 0;
  }
  else {
    switch (num) {                                              //'num'番のブロードキャスト変数へ受信データを格納
      case BR0_PDU:
        par->BR0.val = tmp_packet.val;
        break;
      case BR1_PDU:
        par->BR1.val = tmp_packet.val;
        break;
      case BR2_PDU:
        par->BR2.val = tmp_packet.val;
        break;
      case BR3_PDU:
        par->BR3.val = tmp_packet.val;
        break;
      case BR4_PDU:
        par->BR4.val = tmp_packet.val;
        break;
      case BR5_PDU:
        par->BR5.val = tmp_packet.val;
        break;
      case BR6_PDU:
        par->BR6.val = tmp_packet.val;
        break;
      default:
        return 0;
    }
    return 1;
  }
}


/***************************************************************/
//ブロードキャストパケットのリクエスト（numのブロードキャストを要求)
//引数：
//int num : ブロードキャスト番号
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_reqBRD(int num, ABH3CAN *par){
    for (int i = 0; i < CAN_RETRY; i++) {
      if(_abh3_can_reqBRD(num,par)){
        return 1;
      }
    delay(CAN_WAIT);
    }
return 0;
}
