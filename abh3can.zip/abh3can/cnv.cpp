/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
//ABH3　CAN用　Arduino 　Host
//数値変換関数
//2021.1.19　Waco Giken Co.,Ltd. Ishikawa

#include "ABH3CAN.h"

/***************************************************************/
//速度変換　float => CAN用データ
//引数  ：float vel : 速度[rpm]
//戻り値：速度(CANデータ形式　単位0.2[rpm]）
/***************************************************************/ 
short cnvVel2CAN(float vel)
{
  return (short)(vel/2*10);
}
/***************************************************************/
//速度変換　CAN用データ　=>　float
//引数  ：速度(CANデータ形式　単位0.2[rpm]）
//戻り値：速度[rpm]
/***************************************************************/ 
float cnvCAN2Vel(short vel)
{
  return (float)vel/10.0*2.0;
}

/***************************************************************/
//電流変換　float => CAN用データ
//引数  ：float trq : トルク[%]
//戻り値：電流(CANデータ形式　単位0.01[%]）
/***************************************************************/ 
short cnvCur2CAN(float trq)
{
  return (short)(trq*100.0);
}

/***************************************************************/
//電流変換　CAN用データ　=>　float
//引数  ：電流(CANデータ形式　単位0.01[%]）
//戻り値：float trq : トルク[%]
/***************************************************************/ 
float cnvCAN2Cur(short trq)
{
  return (float)trq/100.0;
}

/***************************************************************/
//負荷率変換　CAN用データ　=>　float
//引数  ：負荷率(CANデータ形式　単位0.1[%]）
//戻り値：float load : 負荷率[%]
/***************************************************************/ 
float cnvCAN2Load(short load)
{
  return (float)((unsigned short)load/10.0);
}

/***************************************************************/
//アナログ入力変換　CAN用データ　=>　float
//引数  ：アナログ入力(CANデータ形式　単位0.01[V]）
//戻り値：float analog : アナログ入力[%]
/***************************************************************/ 
float cnvCAN2Analog(short analog)
{
  return (float)analog/100.0;
}

/***************************************************************/
//電源電圧変換　CAN用データ　=>　float
//引数  ：電源電圧(CANデータ形式　単位0.01[V]）
//戻り値：float volt : 電源電圧[V]
/***************************************************************/ 
float cnvCAN2Volt(short volt)
{
  return (float)((short)volt)/10.0;
}
