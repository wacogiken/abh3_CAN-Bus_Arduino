/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//ABH3　CAN用　Arduino 　Host
//デバック用関数
//2021.1.19　Waco Giken Co.,Ltd. Ishikawa

#include "ABH3CAN.h"

/***************************************************************/
//CAN通信データを表示
// 引数：
// unsigned long Id　：　CAN　ID表示
// unsigned char *data,　：　CAN通信データ格納ポインタ
// unsigned char len : CAN通信データ長
// int flg　：　表示設定フラグ　0:ABH3=>host 1:host=>ABH3　
//戻り値：なし
/***************************************************************/
void com_dump(unsigned long Id, unsigned char *data, unsigned char len, int flg)
{
  char msgString[128];

  if (flg)                                                //CAN-ID表示
    sprintf(msgString, "（HOST)Send   : %.8lX", Id);
  else
    sprintf(msgString, "（HOST)Receive: %.8lX", Id);
  Serial.print(msgString);

  for (int i = 0; i < len ; i++) {                        //データ表示
    sprintf(msgString, "_%.2X", data[i]);
    Serial.print(msgString);
  }
  Serial.println();
}
