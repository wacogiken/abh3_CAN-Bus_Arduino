/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//ABH3　CAN用　Arduino 　Host
//各種定義ヘッダファイル
//2023.2.10　Waco Giken Co.,Ltd. Ishikawa


#include <Arduino.h>

//#define DEBUG_PRINT                   //定義するとCAN通信状態を表示。

#define CAN_TIMEOUT 1000                //CAN受信タイムアウト[sec]
#define CAN0_INT 2                      //MCP2515のINTを D2ピンに設定

#define CAN_RETRY 10                    //送受信失敗時のリトライ回数
#define CAN_WAIT  10                    //送受信失敗時～リトライまでの待機時間[ms]

#define BR0_PDU   0x28                  //ブロードキャスト0　PDU Speciffic 
#define BR1_PDU   (BR0_PDU+1)           //ブロードキャスト1　PDU Speciffic 
#define BR2_PDU   (BR0_PDU+2)           //ブロードキャスト2　PDU Speciffic 
#define BR3_PDU   (BR0_PDU+3)           //ブロードキャスト3　PDU Speciffic 
#define BR4_PDU   (BR0_PDU+4)           //ブロードキャスト4　PDU Speciffic 
#define BR5_PDU   (BR0_PDU+5)           //ブロードキャスト5　PDU Speciffic 
#define BR6_PDU   (BR0_PDU+6)           //ブロードキャスト6　PDU Speciffic 

#define CANID_DP0 0x000000ef            //シングルパケット0 PDU Format  
#define CANID_DP1 0x000001ef            //シングルパケット1 PDU Format  
#define CANID_BRS 0x000000ea            //ブロードキャスト　PDU Format (Host->ABH3)
#define CANID_BRR 0x000000ff            //ブロードキャスト　PDU Format (ABH3->Host)


/********************************/
//戻り値構造体定義
/********************************/

//シングルパケット(DP0S) (Host->ABH3)
typedef union DP0S_u {
  struct DP0S_s {
    uint16_t ay_com;                    // A/Y指令
    uint16_t bx_com;                    // B/X指令
    uint32_t op_flg;                    // 操作フラグ
  } io;
  uint64_t val;                         // DPOS 64bit
  uint8_t d[8];                         // DP0S 配列8byte
} _DP0S;

//シングルパケット(DP0R) (ABH3->Host)
typedef union DP0R_u {
  struct DP0R_s {
    uint16_t ayvel_fb;                   // A/Y速度帰還
    uint16_t byvel_fb;                   // B/X速度帰還
    uint32_t control_flg;                //制御フラグ
  } io;
  uint64_t val;                         // DPOR 64bit
  uint8_t d[8];                         // DP0R 配列8byte
} _DP0R;

//シングルパケット(DP1R) (ABH3->Host)
typedef union DP1R_u {
  struct DP1R_s {
    int32_t apulse;                    // Aパルス積算値
    int32_t bpulse;                    // Bパルス積算値
  } io;
  uint64_t val;                         // DP1R 64bit
  uint8_t d[8];                         // DP1R 配列8byte
} _DP1R;

//ブロードキャスト(BR0) (ABH3->Host)
typedef union br0_u {
  struct br0_s {
    uint32_t  error_flg;                // 異常フラグ
    uint32_t  warning_flg;              // 警告フラグ
  } io;
  uint64_t val;                         // BR0 64bit
  uint8_t d[8];                         // BR0 配列8byte
} _BR0;

//ブロードキャスト(BR1) (ABH3->Host)
typedef union br1_u {
  struct br1_s {
    uint32_t io_flg;                    //ＩＯフラグ
    uint32_t input_flg;                 //入力フラグ
  } io;
  uint64_t val;                         // BR1 64bit
  uint8_t d[8];                         // BR1 配列8byte
} _BR1;

//ブロードキャスト(BR2) (ABH3->Host)
typedef union br2_u {
  struct br2_s {
    uint16_t ayvel_com;               // A/Y速度指令
    uint16_t bxvel_com;               // B/X速度指令
    uint16_t ayvel_fb;                // A/Y速度帰還
    uint16_t bxvel_fb;                // B/X速度帰還
  } io;
  uint64_t val;                       // BR2 64bit
  uint8_t d[8];                       // BR2 配列8byte
} _BR2;

//ブロードキャスト(BR3) (ABH3->Host)
typedef union br3_u {
  struct br3_s {
    uint16_t aycrt_com;               // A/Y電流指令
    uint16_t bxcrt_com;               // B/X電流指令
    uint16_t aload;                   // A負荷率
    uint16_t bload;                   // B負荷率
  } io;
  uint64_t val;                       // BR3 64bit
  uint8_t d[8];                       // BR3 64bit
} _BR3;

//ブロードキャスト(BR4) (ABH3->Host)
typedef union br4_u {
  struct br4_s {
    int32_t apulse_integ;               // Aパルス積算値
    int32_t bpulse_integ;               // Bパルス積算値
  } io;
  uint64_t val;                         // BR4 64bit
  uint8_t d[8];                         // BR4 配列8byte
} _BR4;

//ブロードキャスト(BR5) (ABH3->Host)
typedef union br5_u {
  struct br5_s {
    uint16_t analog_in0;               // アナログ入力0
    uint16_t analog_in1;               // アナログ入力1
    uint16_t main_volt;                // 主電源電圧
    uint16_t ctrl_volt;                // 制御電源電圧
  } io;
  uint64_t val;                         // BR5 64bit
  uint8_t d[8];                         // BR5 配列8byte
} _BR5;

//ブロードキャスト(BR) (ABH3->Host)
typedef union br6_u {
  struct br6_s {
    float moni_data0;               // モニタ0データ
    float moni_data1;               // モニタ1データ
  } io;
  uint64_t val;                         // BR6 64bit
  uint8_t d[8];                         // BR6 配列8byte
} _BR6;


//マルチパケット(BUF) (ABH3->Host)
typedef union buf_u {
  struct rts_s {
    uint8_t  ctrl;               // コントロール
    uint16_t messageSize;        //メッセージバイト数
    uint8_t  totalPacket;        //総パケット数
    uint8_t  maxPacket;          //最大パケット数
    uint16_t PGN;                //マルチパケットPGN
    uint8_t  PGN_H;              //マルチパケットPGN
  } rts;
  struct cts_s {
    uint8_t  ctrl;               // コントロール
    uint8_t packetNum;          //送信可能パケット数
    uint8_t  packetIndex;        //次に送信されるパケット番号
    uint16_t reserve;            //リザーブ
    uint16_t PGN;                //マルチパケットPGN
    uint8_t  PGN_H;              //マルチパケットPGN
  } cts;
  struct cabort_s {
    uint8_t  ctrl;                // コントロール
    uint8_t  reason;              //理由
    uint8_t  reserve0;            //リザーブ
    uint16_t reserve1;            //リザーブ
    uint16_t PGN;                 //マルチパケットPGN
    uint8_t  PGN_H;               //マルチパケットPGN
  } cabort;
  struct ack_s {
    uint8_t  ctrl;               // コントロール
    uint16_t messageSize;        //メッセージバイト数
    uint8_t  totalPacket;        //総パケット数
    uint8_t  reserve  ;          //リザーブ
    uint16_t PGN;                //マルチパケットPGN
    uint8_t  PGN_H;              //マルチパケットPGN
  } ack;
  struct dt_s {
    uint8_t  sequence;           //シーケンス番号
    uint8_t  data1;              //データ1
    uint8_t  data2;              //データ1
    uint8_t  data3;              //データ2
    uint8_t  data4;              //データ3
    uint8_t  data5;              //データ4
    uint8_t  data6;              //データ5
    uint8_t  data7;              //データ6
  } dt;
  uint64_t val;                  // BFU 64bit
  uint8_t d[8];                  // BFU 配列8byte
} _BUF;

//CANアドレス定義
typedef struct setting_s {
  uint8_t abh3_adrs;                   // ABH3アドレス
  uint8_t host_adrs;                   // HOSTアドレス
} _SETTING;


//戻り値構造体
typedef struct _abh3para {
  _DP0S  DP0S;                        //シングルパケット(DP0S) (Host->ABH3)
  _DP0R  DP0R;                        //シングルパケット(DP0R) (ABH3->Host)
  _DP1R  DP1R;                        //シングルパケット(DP1R) (ABH3->Host)
  _BR0 BR0;                           //ブロードキャスト(BR0) (ABH3->Host)
  _BR1 BR1;                           //ブロードキャスト(BR1) (ABH3->Host)
  _BR2 BR2;                           //ブロードキャスト(BR2) (ABH3->Host)
  _BR3 BR3;                           //ブロードキャスト(BR3) (ABH3->Host)
  _BR4 BR4;                           //ブロードキャスト(BR4) (ABH3->Host)
  _BR5 BR5;                           //ブロードキャスト(BR5) (ABH3->Host)
  _BR6 BR6;                           //ブロードキャスト(BR6) (ABH3->Host)
  _BUF BUF;                           //マルチパケット(BUF) (ABH3->Host)
  _SETTING SETTING;                   //CANアドレス定義
} ABH3CAN;


//CANパケットデータ一時保存用共用体
typedef union tmp_packet_s {
  uint64_t val;                         //  64bit
  uint8_t d[8];                         // BFU 配列8byte
}TMPDATA;


/********************************/
//関数宣言
/********************************/
//CAN操作関数　can.cpp
void can_setadrs(unsigned char abh3,unsigned char host,ABH3CAN * par);
int can_init(int bps);
int can_tx(unsigned long canid, unsigned char *candata, unsigned char num);
int can_rx(unsigned long *canid, unsigned char *candata, unsigned char *num);
int abh3_can_init(ABH3CAN *par) ;

//シングルパケット関数　single_packet.cpp
int abh3_can_DP0( ABH3CAN *par);
int abh3_can_DP1( ABH3CAN *par);
int abh3_can_cmdAY(short cmd, ABH3CAN *par);
int abh3_can_cmdBX(short cmd, ABH3CAN *par);
int abh3_can_cmd(short cmdAY, short cmdBX, ABH3CAN *par);
int abh3_can_inSet(long data, long mask , ABH3CAN *par);
int abh3_can_inBitSet(char num, char data , ABH3CAN *par);
int abh3_can_reqPulse(ABH3CAN *par);

//ブロードキャスト関数　broadcast.cpp
int abh3_can_reqBRD(int num, ABH3CAN *par);

//数値変換関数　cnv.cpp
short cnvVel2CAN(float vel);
float cnvCAN2Vel(short vel);
short cnvCur2CAN(float trq);
float cnvCAN2Cur(short trq);
float cnvCAN2Load(short load);
float cnvCAN2Analog(short analog);
float cnvCAN2Volt(short volt);

//デバッグ用　debug.cpp
void com_dump(unsigned long Id, unsigned char *data, unsigned char len, int flg);

//マルチパケット関数 multipacket.cpp
int abh3_can_trans(char *sbuf, char *rbuf, ABH3CAN *par);
