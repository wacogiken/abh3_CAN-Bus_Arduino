/******************************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2021, Waco Giken Co., Ltd.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/o2r other materials provided
 *     with the distribution.
 *   * Neither the name of the Waco Giken nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//ABH3　CAN用　Arduino 　Host
//シングルパケット操作部分
//2023.2.10　Waco Giken Co.,Ltd. Ishikawa

#include "ABH3CAN.h"

/***************************************************************/
//abh3_can_DP0 本体
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　送受信成功:1　　失敗:0
/***************************************************************/
int _abh3_can_DP0( ABH3CAN *par)
{
  unsigned char num;
  unsigned long canid, tmp_canid, abh3_adrs, host_adrs;
  TMPDATA tmp_packet;

//-------------------------------------------------------------　送信CANIDの設定
  abh3_adrs = (unsigned long)par->SETTING.abh3_adrs;        
  host_adrs = (unsigned long)par->SETTING.host_adrs;
  canid = CANID_DP0;
  canid = (canid << 16) | (abh3_adrs << 8)  |  (host_adrs);
//-------------------------------------------------------------
  
  if (! can_tx(canid, par->DP0S.d, 8)) {                      //CAN送信処理
    return 0;
  }
//------------------------------------------------------------- 受信CANIDの設定
  canid = CANID_DP0;
  canid = (canid << 16) | (host_adrs << 8)  |  (abh3_adrs);
//-------------------------------------------------------------


  if (! can_rx(&tmp_canid, tmp_packet.d, &num)) {            //CAN受信処理
    return 0;
  }
  if (tmp_canid != canid || num != 8){                       //受信したCANIDとデータ数の整合チェック
    return 0;
  }
  else {
    par->DP0R.val = tmp_packet.val;                         //整合Okなら構造体へ受信データを格納
    return 1;
  }
}




/***************************************************************/
//abh3_can_DP1本体
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　送受信成功:1　　失敗:0
/***************************************************************/
int _abh3_can_DP1( ABH3CAN *par)
{
  unsigned char tmp = 0;
  unsigned char num;
  unsigned long canid, tmp_canid, abh3_adrs, host_adrs;
  TMPDATA tmp_packet;

//-------------------------------------------------------------　送信CANIDの設定
  abh3_adrs = (unsigned long)par->SETTING.abh3_adrs;
  host_adrs = (unsigned long)par->SETTING.host_adrs;
  canid = CANID_DP1;
  canid = (canid << 16) | (abh3_adrs << 8)  |  (host_adrs);
//-------------------------------------------------------------  
  
  if (! can_tx(canid, &tmp , 0)) {                              //CAN送信処理
    return 0;
  }
  
//-------------------------------------------------------------　受信CANIDの設定
  canid = CANID_DP1;
  canid = (canid << 16) | (host_adrs << 8)  |  (abh3_adrs);
//-------------------------------------------------------------

  if (! can_rx(&tmp_canid, tmp_packet.d, &num)) {            //CAN受信処理
    return 0;
  }
  if (tmp_canid != canid || num != 8){                       //受信したCANIDとデータ数の整合チェック
    return 0;
  }
  else {
    par->DP1R.val = tmp_packet.val;                         //整合Okなら構造体へ受信データを格納
    return 1;
  }
}

/***************************************************************/
//シングルパケットDP0　送受信関数
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　送受信成功:1　　失敗:0
/***************************************************************/
int abh3_can_DP0( ABH3CAN *par){
    for (int i = 0; i < CAN_RETRY; i++) {
      if(_abh3_can_DP0(par)){
        return 1;
      }
    delay(CAN_WAIT);
    }
return 0;
}

/***************************************************************/
//シングルパケットDP1　送受信関数 
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　送受信成功:1　　失敗:0
/***************************************************************/
int abh3_can_DP1( ABH3CAN *par)
{
    for (int i = 0; i < CAN_RETRY; i++) {
      if(_abh3_can_DP1(par)){
        return 1;
      }
    delay(CAN_WAIT);
    }
return 0;
}



/***************************************************************/
//シングルパケットDP0　AY指令設定
//引数：
//short cmd　：　指令値
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_cmdAY(short cmd, ABH3CAN *par)
{
  par->DP0S.io.ay_com = cmd;          
  if (! abh3_can_DP0(par)) {
    return 0;
  }

  return 1;
}

/***************************************************************/
//シングルパケットDP0　BX指令設定
//引数：
//short cmd　：　指令値
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_cmdBX(short cmd, ABH3CAN *par)
{
  par->DP0S.io.bx_com = cmd;           
  if (! abh3_can_DP0(par)) {
    return 0;
  }
  return 1;

}

/***************************************************************/
//シングルパケットDP0　AY/BX指令設定
//引数：
//short cmdAY　：　AY指令値
//short cmdBX　：　BX指令値
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_cmd(short cmdAY, short cmdBX, ABH3CAN *par)
{
  par->DP0S.io.ay_com = cmdAY;         
  par->DP0S.io.bx_com = cmdBX;

  if (! abh3_can_DP0(par)) {
    return 0;
  }

  return 1;

}

/***************************************************************/
//シングルパケットDP0　入力指令設定(maskが'1'のデータを入力に設定）
//引数：
//long data     ： 入力設定値
//long mask     ：　上記入力設定値マスク
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_inSet(long data, long mask , ABH3CAN *par)
{
  par->DP0S.io.op_flg  = (par->DP0S.io.op_flg  & ~mask) | (data & mask);

  if (! abh3_can_DP0(par)) {
    return 0;
  }
  return 1;
}

/***************************************************************/
//シングルパケットDP0　入力指令設定(numで指定したbitのデータを入力に設定）
//引数：
//char num  : ビット番号(0-31)
//char data :　設定データ(0-1)
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_inBitSet(char num, char data , ABH3CAN *par)
{
  num &=  0x1f;
  unsigned long data_l = 1;
  if (data) {
        par->DP0S.io.op_flg  = (par->DP0S.io.op_flg ) | (data_l << num);

  }
  else {
        par->DP0S.io.op_flg  = (par->DP0S.io.op_flg ) & ~(data_l << num);

  }
  if (! abh3_can_DP0(par)) {
    return 0;
  }
  return 1;
}

/***************************************************************/
//シングルパケットDP1　パルス積算値のリクエスト
//引数：
//ABH3CAN *par　：　ABH3CAN操作用構造体
//戻り値：　設定成功:1　　失敗:0
/***************************************************************/
int abh3_can_reqPulse(ABH3CAN *par)
{
  if (! abh3_can_DP1(par)) {
    return 0;
  }
  return 1;
}
